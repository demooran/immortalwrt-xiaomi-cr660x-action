module("luci.controller.vlanwizard", package.seeall)

function index()
    entry({"admin", "network", "vlanwizard"},
          view("vlanwizard/main"),
          _("البرمجة السريعة"),
          90).dependent = false
end
