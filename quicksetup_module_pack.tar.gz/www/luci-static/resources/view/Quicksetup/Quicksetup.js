'use strict';
'require view';
'require dom';
'require poll';
'require uci';
'require rpc';
'require form';
'require tools.widgets as widgets';
'require fs';
'require ui';

return view.extend({
load: function() {
return Promise.all([
uci.changes(),
uci.load('wireless'),
uci.load('network'),
uci.load('Quicksetup')
]);
},

render: function(data) {
var has_wifi = false;

try {
if (uci.sections('wireless', 'wifi-device').length > 0) {
has_wifi = true;
}
} catch (e) {
has_wifi = false;
}

var current_mode = uci.get('Quicksetup', 'default', 'set_Settings') || 'owifi_Vlan';

this.has_wifi = has_wifi;
this.current_mode = current_mode;

this.addStyles();

var params = new URLSearchParams(window.location.search);
var selectedMode = params.get('selectedMode');

if (selectedMode) {
return this.renderConfigForm(selectedMode);
} else {
return this.renderModeSelection();
}
},

addStyles: function() {
if (document.getElementById('Quicksetup-mode-styles')) {
return;
}

var style = E('style', { 'id': 'Quicksetup-mode-styles' }, `
.mode-grid {
display: flex;
flex-wrap: wrap;
gap: 20px;
margin: 30px 0;
justify-content: center;
}

.mode-card {
border-radius: 8px;
padding: 5rem 1rem;
cursor: pointer;
transition: all 0.3s;
text-align: center;
flex: 1;
min-width: 200px;
max-width: 200px;
box-shadow: 0 0.1rem 0.3rem var(--input-boxcolor);
display: flex;
flex-direction: column;
align-items: center;
border: 2px solid transparent;
}

.mode-card:hover {
transform: translateY(-2px);
box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.mode-card[data-mode="pppoe_dial"] {
background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
border-color: #ff4757;
color: white;
}

.mode-card[data-mode="sender_mesh"] {
background: linear-gradient(135deg, #da77f2 0%, #be4bdb 100%);
border-color: #be4bdb;
color: white;
}

.mode-card[data-mode="owifi_Vlan"] {
background: linear-gradient(135deg, #51cf66 0%, #40c057 100%);
border-color: #40c057;
color: white;
}

.mode-card[data-mode="sender_wds"] {
background: linear-gradient(135deg, #339af0 0%, #228be6 100%);
border-color: #228be6;
color: white;
}

.mode-icon-container {
width: 64px;
height: 64px;
margin-bottom: 15px;
display: flex;
align-items: center;
justify-content: center;
background: rgba(255, 255, 255, 0.2);
border-radius: 50%;
padding: 10px;
}

.mode-icon-bg {
width: 64px;
height: 64px;
margin-bottom: 15px;
display: flex;
align-items: center;
justify-content: center;
border-radius: 50%;
padding: 10px;
}

.mode-icon {
width: 48px;
height: 48px;
object-fit: contain;
}

.mode-title {
font-size: 16px;
font-weight: 600;
margin-top: 10px;
text-align: center;
}

.Quicksetup-nav-buttons {
display: flex;
justify-content: center;
gap: 10px;
margin: 20px;
flex-wrap: wrap;
}

.Quicksetup-nav-btn {
padding: 8px 16px;
color: white;
border: none;
border-radius: 4px;
font-size: 14px;
line-height: 1rem;
cursor: pointer;
transition: background 0.3s;
text-decoration: none;
display: inline-block;
}

.mode-info-header {
border-radius: 8px;
padding: 1rem;
margin: 0 2% 2% 2%;
display: flex;
align-items: center;
gap: 15px;
}

.mode-info-content {
flex: 1;
}

.mode-info-header[data-mode="pppoe_dial"] { background: #ff6b6b; }
.mode-info-header[data-mode="sender_mesh"] { background: #da77f2; }
.mode-info-header[data-mode="owifi_Vlan"] { background: #51cf66; }
.mode-info-header[data-mode="sender_wds"] { background: #339af0; }

@media (max-width: 768px) {
.mode-grid { flex-direction: column; align-items: center; }
.mode-card { min-width: 100%; max-width: 100%; }
.Quicksetup-nav-buttons { flex-direction: column; }
.Quicksetup-nav-btn { width: 100%; text-align: center; }
.mode-info-header { flex-direction: column; text-align: center; }
}
`);
document.head.appendChild(style);
},

getModeIconBase64: function(mode) {
switch (mode) {
case 'pppoe_dial':
return 'data:image/svg+xml;base64,' + btoa('<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40"><path fill="white" d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM19 18H6c-2.21 0-4-1.79-4-4s1.79-4 4-4h.71C7.37 7.69 9.48 6 12 6c2.76 0 5 2.24 5 5v2h2c1.66 0 3 1.34 3 3s-1.34 3-3 3z"/></svg>');
case 'sender_mesh':
return 'data:image/svg+xml;base64,' + btoa('<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40"><path fill="white" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8-8-3.59-8-8zm11 0c0-1.66-1.34-3-3-3s-3 1.34-3 3 1.34 3 3 3 3-1.34 3-3z"/></svg>');
case 'owifi_Vlan':
return 'data:image/svg+xml;base64,' + btoa('<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40"><path fill="white" d="M12 3C7.79 3 4.14 5.34 2.29 8.5c-.37.66.11 1.5.9 1.5h17.63c.79 0 1.27-.84.9-1.5C19.86 5.34 16.21 3 12 3zm0 5c-1.38 0-2.5 1.12-2.5 2.5S10.62 13 12 13s2.5-1.12 2.5-2.5S13.38 8 12 8zm0 6c-2.33 0-7 1.17-7 3.5V19h14v-1.5c0-2.33-4.67-3.5-7-3.5z"/></svg>');
case 'sender_wds':
return 'data:image/svg+xml;base64,' + btoa('<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40"><path fill="white" d="M6.99 11L3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z"/></svg>');
default:
return '';
}
},

getModeIcon: function(mode) {
var svgUrl = this.getModeIconBase64(mode);
return '<img src="' + svgUrl + '" alt="' + mode + ' icon" class="mode-icon">';
},

getModeTitle: function(mode) {
switch (mode) {
case 'pppoe_dial': return _('اتصال PPPoE');
case 'owifi_Vlan': return _('نقطة وصول (Access Point)');
case 'sender_wds': return _('إعداد WDS');
case 'sender_mesh': return _('شبكة MESH');
default: return _('وضع غير معروف');
}
},

getModeDescription: function(mode) {
switch (mode) {
case 'pppoe_dial': return _('للاتصال عبر ADSL أو الألياف باستخدام اسم مستخدم وكلمة مرور.');
case 'owifi_Vlan': return _('وضع نقطة الوصول مع دعم VLAN.');
case 'sender_wds': return _('نظام التوزيع اللاسلكي لتوسيع التغطية.');
case 'sender_mesh': return _('شبكات MESH للتجوال السلس وتغطية كاملة.');
default: return _('اختر وضع التشغيل المناسب.');
}
},

getModeColor: function(mode) {
switch (mode) {
case 'pppoe_dial': return '#ff6b6b';
case 'sender_mesh': return '#da77f2';
case 'owifi_Vlan': return '#51cf66';
case 'sender_wds': return '#339af0';
default: return '#36c';
}
},

renderModeSelection: function() {
var container = E('div', { 'class': 'mode-selection-container' }, [
E('h3', { 'style': 'margin-top: 4%; margin-bottom: 15px; text-align: center;' }, _('اختر وضع التشغيل')),
E('p', { 'style': 'margin-bottom: 1%; text-align: center;' }, _('اختر وضع التشغيل اللاسلكي لجهازك:'))
]);

var modeGrid = E('div', { 'class': 'mode-grid' });
var modes = [
{ id: 'pppoe_dial' },
{ id: 'owifi_Vlan' },
{ id: 'sender_wds' },
{ id: 'sender_mesh' }
];

var self = this;
modes.forEach(function(mode) {
var iconDiv = E('div', { 'class': 'mode-icon-container' });
iconDiv.innerHTML = self.getModeIcon(mode.id);

var card = E('div', {
'class': 'mode-card',
'data-mode': mode.id
}, [
iconDiv,
E('div', { 'class': 'mode-title' }, self.getModeTitle(mode.id))
]);

card.addEventListener('click', function() {
self.selectMode(mode.id);
});

modeGrid.appendChild(card);
});

container.appendChild(modeGrid);
return container;
},

selectMode: function(mode) {
uci.set('Quicksetup', 'default', 'set_Settings', mode);
uci.save();

var currentUrl = window.location.pathname;
var targetTab = (mode === 'pppoe_dial') ? 'wansetup' : 'wifisetup';
window.location.href = currentUrl + '?selectedMode=' + mode + '&tab=' + targetTab;
},

renderConfigForm: function(selectedMode) {
var currentMode = selectedMode || this.current_mode;
this.map = m = new form.Map('Quicksetup', _('الإعداد السريع'), _('قم بتكوين إعدادات جهازك بناءً على الوضع المحدد.'));

var s = m.section(form.NamedSection, 'default', 'Quicksetup');
s.addremove = false;
s.anonymous = true;

s.tab('modesetup', _('الوضع الحالي'));
s.tab('wansetup', _('إعدادات WAN'), _('إعدادات اتصال الإنترنت'));
if (this.has_wifi) {
s.tab('wifisetup', _('الإعدادات اللاسلكية'), _('جميع الحقوق محفوظة لمكتب الحسام 2022'));
}
s.tab('lansetup', _('إعدادات إضافية'), _('إعدادات النظام والحماية'));

var modeTitle = this.getModeTitle(currentMode);
var modeIcon = this.getModeIcon(currentMode);
var modeDescription = this.getModeDescription(currentMode);
var modeColor = this.getModeColor(currentMode);

var primaryTab = (currentMode === 'pppoe_dial') ? 'wansetup' : 'wifisetup';
var buttonText = (currentMode === 'pppoe_dial') ? _('انتقل إلى إعدادات WAN') : _('انتقل إلى الإعدادات اللاسلكية');

var curLanIp = uci.get('Quicksetup', 'default', 'lan_ipaddr') || uci.get('network', 'lan', 'ipaddr') || '10.0.0.113';
var curLanMask = uci.get('Quicksetup', 'default', 'lan_netmask') || uci.get('network', 'lan', 'netmask') || '255.255.255.0';
var curSsid = uci.get('Quicksetup', 'default', 'wifi_ssid') || uci.get('wireless', 'ap_2g', 'ssid') || uci.get('wireless', 'default_radio0', 'ssid') || '';
var curCh2g = uci.get('Quicksetup', 'default', 'radio0_channel') || uci.get('wireless', 'radio0', 'channel') || '5';
var curCh5g = uci.get('Quicksetup', 'default', 'radio1_channel') || uci.get('wireless', 'radio1', 'channel') || '149';

var o = s.taboption('modesetup', form.DummyValue, 'current_mode_display', _('حالة الوضع الحالي'));
o.rawhtml = true;
o.default = '<div style="display: flex;align-items: center;flex-direction: column;">' +
'<div class="mode-icon-bg" style="margin-bottom: 20px;background: ' + modeColor + ';">' + modeIcon + '</div>' +
'<h3>' + modeTitle + '</h3>' +
'<p>' + modeDescription + '</p>' +
'<div class="Quicksetup-nav-buttons">' +
'<button type="button" onclick="switchToTab(\'' + primaryTab + '\')" class="Quicksetup-nav-btn" style="background: ' + modeColor + ';">' +
'⚙️ ' + buttonText + '</button>' +
'<a href="' + window.location.pathname + '" class="Quicksetup-nav-btn cbi-button cbi-button-reset" style="color: #ffffff !important;">' +
'↻ ' + _('تغيير الوضع') + '</a>' +
'</div></div>';

o = s.taboption('modesetup', form.ListValue, 'set_Settings', _('وضع التشغيل'));
o.value('pppoe_dial', _('اتصال PPPoE'));
o.value('owifi_Vlan', _('نقطة وصول'));
o.value('sender_wds', _('WDS'));
o.value('sender_mesh', _('MESH'));
o.default = currentMode;
o.readonly = true;
o.rmempty = false;

var modeInfoHeaderWan = s.taboption('wansetup', form.DummyValue, 'mode_info_header_wan', '');
modeInfoHeaderWan.rawhtml = true;
modeInfoHeaderWan.default = '<div class="mode-info-header" data-mode="' + currentMode + '">' +
'<div class="mode-icon-container cbi-value-title">' + modeIcon + '</div>' +
'<div class="mode-info-content cbi-value-field">' +
'<h4 style="margin: 0 0 5px 0; color: #fff;">' + modeTitle + '</h4>' +
'<p style="margin: 0; font-size: 14px; color: #fff;">' + modeDescription + '</p>' +
'<div style="margin: 10px;">' +
'<a href="' + window.location.pathname + '" class="Quicksetup-nav-btn cbi-button cbi-button-reset" style="color: #ffffff !important;">' +
'↻ ' + _('تغيير الوضع') + '</a>' +
'</div></div></div>';

var modeInfoHeaderWifi = s.taboption('wifisetup', form.DummyValue, 'mode_info_header_wifi', '');
modeInfoHeaderWifi.rawhtml = true;
modeInfoHeaderWifi.default = '<div class="mode-info-header" data-mode="' + currentMode + '">' +
'<div class="mode-icon-container cbi-value-title">' + modeIcon + '</div>' +
'<div class="mode-info-content cbi-value-field">' +
'<h4 style="margin: 0 0 5px 0; color: #fff;">' + modeTitle + '</h4>' +
'<p style="margin: 0; font-size: 14px; color: #fff;">' + modeDescription + '</p>' +
'<div style="margin: 10px;">' +
'<a href="' + window.location.pathname + '" class="Quicksetup-nav-btn cbi-button cbi-button-reset" style="color: #ffffff !important;">' +
'↻ ' + _('تغيير الوضع') + '</a>' +
'</div></div></div>';

o = s.taboption('wansetup', widgets.DeviceSelect, 'wan_interface', _('واجهة WAN'), _('اختر الواجهة الفعلية لاتصال WAN'));
o.depends('set_Settings', 'pppoe_dial');
o.noaliases = true;
o.rmempty = true;

o = s.taboption('wansetup', form.Value, 'wan_pppoe_user', _('اسم مستخدم PPPoE'));
o.depends('set_Settings', 'pppoe_dial');

o = s.taboption('wansetup', form.Value, 'wan_pppoe_pass', _('كلمة مرور PPPoE'));
o.depends('set_Settings', 'pppoe_dial');
o.password = true;
o.rmempty = true;

o = s.taboption('wansetup', form.DynamicList, 'wan_dns', _('خوادم DNS مخصصة'));
o.value('8.8.8.8', _('Google DNS (8.8.8.8)'));
o.value('1.1.1.1', _('Cloudflare DNS (1.1.1.1)'));
o.depends('set_Settings', 'pppoe_dial');
o.datatype = 'ip4addr';
o.rmempty = true;

o = s.taboption('wansetup', form.Flag, 'ipv6', _('تفعيل IPv6'));
o.depends('set_Settings', 'pppoe_dial');
o.default = '0';
o.rmempty = true;

o = s.taboption('wansetup', form.Flag, 'lan_dhcp', _('تعطيل خادم DHCP'), _('قم بوضع علامة لتعطيل خادم DHCP على الشبكة المحلية'));
o.depends('set_Settings', 'pppoe_dial');
o.default = '0';
o.rmempty = true;

if (this.has_wifi) {
o = s.taboption('wifisetup', form.Value, 'lan_ipaddr', _('عنوان IPv4'));
o.datatype = 'ip4addr';
o.default = curLanIp;

o = s.taboption('wifisetup', form.Value, 'lan_netmask', _('قناع الشبكة IPv4'));
o.datatype = 'ip4addr';
o.value('255.255.255.0');
o.value('255.255.0.0');
o.value('255.0.0.0');
o.default = curLanMask;

o = s.taboption('wifisetup', form.Value, 'wifi_ssid', _('اسم الشبكة (SSID)'));
o.datatype = 'maxlength(32)';
o.default = curSsid;
o.rmempty = true;

o = s.taboption('wifisetup', form.ListValue, 'radio0_channel', _('2.4GHz'));
o.rmempty = true;
o.value('auto', _('تلقائي'));
for (var i = 1; i <= 11; i++) o.value(String(i));
o.default = String(curCh2g);

o = s.taboption('wifisetup', form.ListValue, 'radio1_channel', _('5GHz'));
o.rmempty = true;
o.value('auto', _('تلقائي'));
[36,40,44,48,52,56,60,64,100,104,108,112,116,120,124,128,132,136,140,149,153,157,161,165].forEach(function(ch) {
o.value(String(ch), ch + ' (' + (5000 + ch * 5) + ' MHz)');
});
o.default = String(curCh5g);

o = s.taboption('wifisetup', form.ListValue, 'num_guest_ssids', _('عدد الشبكات الإضافية'), _('سيتم إنشاء نقاط بث إضافية على الترددين 2.4/5 جيجاهرتز بنفس كلمة المرور الرئيسية (إن وجدت) ولكن بأسماء منفصلة.'));
o.value('0', _('0 - لا يوجد'));
o.value('1', _('1'));
o.value('2', _('2'));
o.value('3', _('3'));
o.default = '0';
o.rmempty = false;

o = s.taboption('wifisetup', form.ListValue, 'wds_type', _('نوع WDS'));
o.depends('set_Settings', 'sender_wds');
o.rmempty = true;
o.value('Sendvlan', _('مرسل (Sender)'));
o.value('Resndvlan', _('مستقبل (Receiver)'));

o = s.taboption('wifisetup', form.Value, 'ssid_wds_out', _('عنوان WDS (للمرسل)'));
o.depends('wds_type', 'Sendvlan');
o.datatype = 'maxlength(32)';
o.rmempty = true;

o = s.taboption('wifisetup', form.Value, 'ssid_wds_in', _('عنوان WDS (للمستقبل)'));
o.depends('wds_type', 'Resndvlan');
o.datatype = 'maxlength(32)';
o.rmempty = true;

o = s.taboption('wifisetup', form.ListValue, 'wds_sender_hide_or', _('التشفير'));
o.depends('set_Settings', 'sender_wds');
o.rmempty = true;
o.value('hideSendvlan', _('مخفي'));
o.value('passResndvlan', _('كلمة مرور'));

o = s.taboption('wifisetup', form.Value, 'sender_key', _('كلمة المرور'));
o.depends('wds_sender_hide_or', 'passResndvlan');
o.datatype = 'wpakey';
o.password = true;

o = s.taboption('wifisetup', form.ListValue, 'sender_Vlan', _('إضافة VLAN'));
o.depends('set_Settings', 'sender_wds');
o.rmempty = true;
o.value('Nvlan', _('بدون VLAN'));
o.value('Wvlan', _('مع VLAN'));

o = s.taboption('wifisetup', form.Value, 'sender_wifi_Vlan', _('رقم VLAN'));
o.depends('sender_Vlan', 'Wvlan');
o.datatype = 'range(1, 4094)';
o.rmempty = true;

o = s.taboption('wifisetup', form.Value, 'Mesh_wifi_ssid', _('عنوان Mesh'));
o.depends('set_Settings', 'sender_mesh');
o.datatype = 'maxlength(32)';
o.rmempty = true;

o = s.taboption('wifisetup', form.ListValue, 'mesh_sender_hide_or', _('التشفير'));
o.depends('set_Settings', 'sender_mesh');
o.rmempty = true;
o.value('hideSendmesh', _('بدون'));
o.value('passResndmesh', _('كلمة مرور'));

o = s.taboption('wifisetup', form.Value, 'mesh_key', _('كلمة المرور'));
o.depends('mesh_sender_hide_or', 'passResndmesh');
o.datatype = 'sae';
o.password = true;

o = s.taboption('wifisetup', form.ListValue, 'mesh_Vlan', _('إضافة VLAN'));
o.depends('set_Settings', 'sender_mesh');
o.rmempty = true;
o.value('mNvlan', _('بدون VLAN'));
o.value('mWvlan', _('مع VLAN'));

o = s.taboption('wifisetup', form.Value, 'mesh_wifi_Vlan', _('رقم VLAN'));
o.depends('mesh_Vlan', 'mWvlan');
o.datatype = 'range(1, 4094)';
o.rmempty = true;

o = s.taboption('wifisetup', form.Flag, 'wifi_flag_Vlan', _('إضافة VLAN'));
o.depends('set_Settings', 'owifi_Vlan');
o.rmempty = true;

o = s.taboption('wifisetup', form.Value, 'wifi_Vlan', _('رقم VLAN'));
o.depends('wifi_flag_Vlan', '1');
o.datatype = 'range(1, 4094)';
o.rmempty = true;

o = s.taboption('wifisetup', form.Flag, 'wifi_key_nVlan', _('حماية كلمة مرور Wi-Fi'));
o.rmempty = true;

o = s.taboption('wifisetup', form.Value, 'wifi_key', _('كلمة المرور'));
o.depends('wifi_key_nVlan', '1');
o.datatype = 'wpakey';
o.password = true;

o = s.taboption('wifisetup', form.Flag, 'Vlan_normal_pass', _('إخفاء الشبكة'));
o.depends('owifi_Vlan', '1');
o.rmempty = true;

o = s.taboption('wifisetup', form.Value, 'Vlan_normal_key', _('كلمة المرور'));
o.depends('Vlan_normal_pass', '1');
o.datatype = 'wpakey';
o.password = true;
}

o = s.taboption('lansetup', form.Flag, 'n_reset', _('حماية من السرقة'), _('تمكين / تعطيل زر الفورمات'));
o.depends('min_reboot', '0');
o.default = '0';
o.rmempty = true;

o = s.taboption('lansetup', form.Flag, 'min_reboot', _('ضبط المهلة الزمنية لاستجابة زر الفورمات'));
o.default = '1';
o.rmempty = true;

o = s.taboption('lansetup', form.Value, 'reset_timer', _('ضبط المهلة (بالثواني)'));
o.depends('min_reboot', '1');
o.default = '15';
o.datatype = 'range(5, 1000)';
o.rmempty = true;

o = s.taboption('lansetup', form.Value, 'root_password', _('تعيين كلمة مرور الراوتر'));
o.password = true;
o.rmempty = true;
o.datatype = 'minlength(1)';
o.placeholder = _('كلمة المرور الجديدة');

o = s.taboption('lansetup', form.Flag, 'enable_port_isolation', _('Enable Port Isolation'), _('Prevents communication between devices.'));
o.rmempty = false;
o.default = '0';

o = s.taboption('wifisetup', form.Flag, 'wifi_performance_tune', _('تحسين أداء الواي فاي'), _('تحسين جودة الإشارة وأداء المعالج (قد يزيد استهلاك الطاقة قليلاً)'));
o.rmempty = false;
o.default = '0';

var script = document.createElement('script');
script.textContent = `
function switchToTab(tabName) {
var tabs = document.querySelectorAll('.cbi-tabmenu a');
for (var i = 0; i < tabs.length; i++) {
var tab = tabs[i];
var tabText = tab.textContent || tab.innerText;
if ((tabName === 'wifisetup' && (tabText.includes('Wireless') || tabText.includes('WLAN') || tabText.includes('اللاسلكية'))) ||
(tabName === 'wansetup' && (tabText.includes('WAN') || tabText.includes('Internet'))) ||
(tabName === 'modesetup' && (tabText.includes('Mode') || tabText.includes('الوضع'))) ||
(tabName === 'lansetup' && (tabText.includes('More') || tabText.includes('إضافية')))) {
tab.click();
break;
}
}
}
`;
document.head.appendChild(script);
		return m.render();
	},
handleSaveApply: function(ev) {
var self = this;
var sid = 'default';
var cfg = 'Quicksetup';
var getVal = function(opt) {
if (self.map && typeof self.map.lookupOption === 'function') {
var res = self.map.lookupOption(opt, sid, cfg);
if (res && res[0] && typeof res[0].formvalue === 'function' && res[0].isActive(sid)) {
return res[0].formvalue(sid);
}
}
var el = document.getElementById('cbid.' + cfg + '.' + sid + '.' + opt);
if (!el) el = document.querySelector('[id^="cbid.' + cfg + '.' + sid + '.' + opt + '"]');
if (!el) el = document.querySelector('[name="cbid.' + cfg + '.' + sid + '.' + opt + '"]');
if (!el) {
var wrap = document.getElementById('cbi-' + cfg + '-' + sid + '-' + opt);
if (wrap) el = wrap.querySelector('input, select, textarea');
}
if (el) {
if (el.type === 'checkbox') return el.checked ? '1' : '0';
if (typeof el.value !== 'undefined') return el.value;
}
return null;
};

var opts = [
'lan_ipaddr', 'lan_netmask', 'wifi_ssid', 'radio0_channel',
'radio1_channel', 'num_guest_ssids', 'wifi_flag_Vlan', 'wifi_Vlan',
'wifi_key_nVlan', 'wifi_key', 'enable_port_isolation', 'wifi_performance_tune'
];

opts.forEach(function(opt) {
var v = getVal(opt);
if (v !== null && v !== undefined) {
uci.set(cfg, sid, opt, String(v));
}
});

return Promise.resolve(uci.save()).then(function() {
return fs.exec('/usr/sbin/quicksetup-apply');
}).then(function(res) {
if (res && res.code !== 0) {
ui.addNotification(null, E('p', {}, _('فشل تطبيق الإعدادات: ') + (res.stderr || res.code)));
} else {
ui.addNotification(null, E('p', {}, _('تم حفظ وتطبيق إعدادات Quicksetup بنجاح.')), 'info');
var badge = document.querySelector('.label.warning, [href*="changes"], .luci-unsaved');
if (badge) {
setTimeout(function() { badge.click(); }, 300);
}
}
}).catch(function(err) {
ui.addNotification(null, E('p', {}, _('خطأ أثناء الحفظ أو التطبيق: ') + (err && err.message ? err.message : err)));
});
}
});
